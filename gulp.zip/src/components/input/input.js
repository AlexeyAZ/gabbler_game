export default function input() {
	
}
