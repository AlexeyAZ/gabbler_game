export default function info-card() {
	
}
