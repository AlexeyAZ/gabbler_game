export default function sec5() {
	
}
