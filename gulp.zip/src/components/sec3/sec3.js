export default function sec3() {
	
}
