export default function hash-btn() {
	
}
