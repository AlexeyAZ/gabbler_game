export default function apps-note() {
	
}
