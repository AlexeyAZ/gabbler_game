export default function apps-footer() {
	
}
