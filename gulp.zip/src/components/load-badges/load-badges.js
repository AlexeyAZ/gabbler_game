export default function load-badges() {
	
}
