export default function footer() {
	
}
