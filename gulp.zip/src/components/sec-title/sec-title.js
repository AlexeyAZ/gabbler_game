export default function sec-title() {
	
}
